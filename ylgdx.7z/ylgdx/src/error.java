import javax.swing.*;

public class error {
    private JButton 确定Button;
}
