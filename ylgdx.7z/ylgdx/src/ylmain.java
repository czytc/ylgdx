import javax.swing.*;
import java.awt.*;

public class ylmain {

    public Container ylmain;
    private JPanel jname;

    public static void main(String[] args) {
        JFrame frame = new JFrame("ylmain");
        frame.setContentPane(new ylmain().jname);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
