import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class test {
    private JPanel login;
    private JEditorPane editorPane1;
    private JLabel username;
    private JPanel usernameJP;
    private JButton loginButton;

    public static void main(String[] args) {
        JFrame frame = new JFrame("login");
        frame.setContentPane(new test().login);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        JButton loginButton = new test().loginButton;
//        frame.getContentPane().add(loginButton);
        System.out.println(loginButton);
        frame.setVisible(true);
    }

    public void runLogin(JFrame frame, JButton loginButton){
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                frame.setContentPane(new ylmain().ylmain);
            }
        });
    }
}
