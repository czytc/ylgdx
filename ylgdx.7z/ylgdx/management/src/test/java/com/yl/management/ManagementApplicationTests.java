package com.yl.management;

import com.yl.management.login.entity.YlAdminEntity;
import com.yl.management.login.service.YlAdminService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagementApplicationTests {

	@Autowired
	YlAdminService ylAdminService;

	@Test
	void contextLoads() {
//		YlAdminEntity ylAdminEntity = new YlAdminEntity();
//		ylAdminEntity.setName("yl");
//		ylAdminEntity.setPassword("123456");
//		ylAdminService.save(ylAdminEntity);
	}

}
