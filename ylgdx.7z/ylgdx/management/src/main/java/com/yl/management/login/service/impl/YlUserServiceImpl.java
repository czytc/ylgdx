package com.yl.management.login.service.impl;

import com.yl.management.utils.PageUtils;
import com.yl.management.utils.Query;
import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.yl.management.login.dao.YlUserDao;
import com.yl.management.login.entity.YlUserEntity;
import com.yl.management.login.service.YlUserService;


@Service("ylUserService")
public class YlUserServiceImpl extends ServiceImpl<YlUserDao, YlUserEntity> implements YlUserService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<YlUserEntity> page = this.page(
                new Query<YlUserEntity>().getPage(params),
                new QueryWrapper<YlUserEntity>()
        );

        return new PageUtils(page);
    }

}