package com.yl.management.login.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yl.management.login.entity.YlAdminEntity;
import com.yl.management.utils.PageUtils;

import java.util.Map;

/**
 * 
 *
 * @author me
 * @email me@gmail.com
 * @date 2021-06-11 14:38:35
 */
public interface YlAdminService extends IService<YlAdminEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

