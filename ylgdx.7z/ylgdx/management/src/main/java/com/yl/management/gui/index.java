package com.yl.management.gui;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.yl.management.login.entity.YlUserEntity;
import com.yl.management.login.service.YlUserService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;


public class index {
    private static final JFrame frame = new JFrame("index");
    private JPanel index;
    private YlUserService ylUserService;

    public index(YlUserService ylUserService) {
        this.ylUserService = ylUserService;

        增加Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                YlUserEntity ylUserEntity = new YlUserEntity();
                ylUserEntity.setName(textField1.getText());
                ylUserEntity.setPassword(String.valueOf(passwordField1.getPassword()));
                if (!textField2.getText().equals("")){
                    ylUserEntity.setSex(textField2.getText());
                } else {
                    ylUserEntity.setSex("不明");
                }
                if(!textField3.getText().equals("")){
                    ylUserEntity.setType(textField3.getText());
                } else {
                    ylUserEntity.setType("不明生物");
                }

                try{
                    int choose = JOptionPane.showConfirmDialog(null, "是否插入数据");
                    if (choose==0){
                        ylUserService.save(ylUserEntity);
                        JOptionPane.showMessageDialog(null, "插入成功!", "", JOptionPane.INFORMATION_MESSAGE);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                    if (ylUserEntity.getName()==null || ylUserEntity.getPassword()==null){
                        JOptionPane.showMessageDialog(null, "插入失败: 会员名或密码不能为空", "", JOptionPane.ERROR_MESSAGE);
                    }
                    else {
                        JOptionPane.showMessageDialog(null, "插入失败: 会员名已存在", "", JOptionPane.ERROR_MESSAGE);
                    }
                }

            }
        });
        删除Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                YlUserEntity yl = new YlUserEntity();
                if(!textField1.getText().equals("")){
                    yl.setName(textField1.getText());
                }
                if(!String.valueOf(passwordField1.getPassword()).equals("")) {
                    yl.setPassword(String.valueOf(passwordField1.getPassword()));
                }
                if(!textField2.getText().equals("")){
                    yl.setSex(textField2.getText());
                }
                if(!textField3.getText().equals("")){
                    yl.setType(textField3.getText());
                }
                int choose = JOptionPane.showConfirmDialog(null, "是否删除数据");

                if(choose==0){
                    Boolean result = ylUserService.remove(new QueryWrapper<>(yl));

                    if(!result){
                        JOptionPane.showMessageDialog(null, "删除失败: 未找到相应数据", "", JOptionPane.ERROR_MESSAGE);
                    }
                    else {
                        JOptionPane.showMessageDialog(null, "删除成功!", "", JOptionPane.INFORMATION_MESSAGE);
                    }
                }

            }
        });
        修改Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                YlUserEntity yl = new YlUserEntity();
                yl.setName(textField4.getText());
                List<YlUserEntity> data = ylUserService.list(new QueryWrapper<>(yl));
                try {
                    YlUserEntity ylUserEntity = data.get(0);
                    ylUserEntity.setName(textField1.getText());
                    ylUserEntity.setPassword(String.valueOf(passwordField1.getPassword()));
                    if (!textField2.getText().equals("")){
                        ylUserEntity.setSex(textField2.getText());
                    } else {
                        ylUserEntity.setSex("不明");
                    }
                    if(!textField3.getText().equals("")){
                        ylUserEntity.setType(textField3.getText());
                    } else {
                        ylUserEntity.setType("不明生物");
                    }
                    int choose = JOptionPane.showConfirmDialog(null, "是否修改数据");
                    if (choose==0){
                        ylUserService.updateById(ylUserEntity);
                        JOptionPane.showMessageDialog(null, "更新成功!", "", JOptionPane.INFORMATION_MESSAGE);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "更新失败: 未找到会员名", "", JOptionPane.ERROR_MESSAGE);
                }

            }
        });
        查询Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                YlUserEntity yl = new YlUserEntity();
                if(!textField1.getText().equals("")){
                    yl.setName(textField1.getText());
                }
                if(!String.valueOf(passwordField1.getPassword()).equals("")) {
                    yl.setPassword(String.valueOf(passwordField1.getPassword()));
                }
                if(!textField2.getText().equals("")){
                    yl.setSex(textField2.getText());
                }
                if(!textField3.getText().equals("")){
                    yl.setType(textField3.getText());
                }
                List<YlUserEntity> data = ylUserService.list(new QueryWrapper<>(yl));
                rowData = new Object[data.size()][4];
                for (int i = 0; i < data.size(); i++) {
                    YlUserEntity ylUserEntity = data.get(i);
                    rowData[i][0] = ylUserEntity.getName();
                    rowData[i][1] = "******";
                    rowData[i][2] = ylUserEntity.getSex();
                    rowData[i][3] = ylUserEntity.getType();
                }
                JOptionPane.showMessageDialog(null, "查询完成!", "", JOptionPane.INFORMATION_MESSAGE);
                TableModel dataModel = new DefaultTableModel(rowData,columnNames);
                table1.setModel(dataModel);
            }
        });
    }

    public static JFrame getFrame() {
        return frame;
    }

    // 表头（列名）
    Object[] columnNames = {"会员名", "密码", "性别", "种类"};

    // 表格所有行数据
    Object[][] rowData;

    private JTable table1;
    private JTextField textField1;
    private JPasswordField passwordField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JButton 增加Button;
    private JButton 删除Button;
    private JButton 修改Button;
    private JButton 查询Button;

    void adsif(){
        List<YlUserEntity> data = ylUserService.list(new QueryWrapper<YlUserEntity>().last("limit 10"));
        rowData = new Object[data.size()][4];
        for (int i = 0; i < data.size(); i++) {
            YlUserEntity ylUserEntity = data.get(i);
            rowData[i][0] = ylUserEntity.getName();
            rowData[i][1] = "******";
            rowData[i][2] = ylUserEntity.getSex();
            rowData[i][3] = ylUserEntity.getType();
        }
        TableModel dataModel = new DefaultTableModel(rowData,columnNames);
        table1.setModel(dataModel);
    }

    public void entry() {
        JFrame frame = getFrame();
        frame.setContentPane(index);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        adsif();
    }
}
