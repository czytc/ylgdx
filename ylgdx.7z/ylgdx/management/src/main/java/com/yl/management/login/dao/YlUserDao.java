package com.yl.management.login.dao;

import com.yl.management.login.entity.YlUserEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author me
 * @email me@gmail.com
 * @date 2021-06-11 14:38:35
 */
@Mapper
public interface YlUserDao extends BaseMapper<YlUserEntity> {
	
}
