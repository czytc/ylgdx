package com.yl.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.awt.*;

@SpringBootApplication
public class ManagementApplication extends Frame {

	public static void main(String[] args) {
		SpringApplication.run(ManagementApplication.class, args);
	}

}
