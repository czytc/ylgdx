package com.yl.management.login.service.impl;

import com.yl.management.utils.PageUtils;
import com.yl.management.utils.Query;
import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.yl.management.login.dao.YlAdminDao;
import com.yl.management.login.entity.YlAdminEntity;
import com.yl.management.login.service.YlAdminService;


@Service("ylAdminService")
public class YlAdminServiceImpl extends ServiceImpl<YlAdminDao, YlAdminEntity> implements YlAdminService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<YlAdminEntity> page = this.page(
                new Query<YlAdminEntity>().getPage(params),
                new QueryWrapper<YlAdminEntity>()
        );

        return new PageUtils(page);
    }

}