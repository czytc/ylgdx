package com.yl.management.controller;


import com.yl.management.gui.login;
import com.yl.management.login.service.YlUserService;
import com.yl.management.utils.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yl.management.login.service.YlAdminService;



/**
 * 
 *
 * @author me
 * @email me@gmail.com
 * @date 2021-06-08 13:59:53
 */
@RestController
@RequestMapping("login/yladmin")
public class YlAdminController {
    @Autowired
    private YlAdminService ylAdminService;

    @Autowired
    private YlUserService ylUserService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    public R list(){
        login login = new login(ylAdminService, ylUserService);
        login.entry();
        return R.ok();
    }

}
