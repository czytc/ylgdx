package com.yl.management.login.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yl.management.login.entity.YlUserEntity;
import com.yl.management.utils.PageUtils;

import java.util.Map;

/**
 * 
 *
 * @author me
 * @email me@gmail.com
 * @date 2021-06-11 14:38:35
 */
public interface YlUserService extends IService<YlUserEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

