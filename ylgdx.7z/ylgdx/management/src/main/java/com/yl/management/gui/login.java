package com.yl.management.gui;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.yl.management.login.entity.YlAdminEntity;
import com.yl.management.login.service.YlAdminService;
import com.yl.management.login.service.YlUserService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.List;

public class login{
    private YlAdminService ylAdminService;
    private YlUserService ylUserService;
    public Container login1;
    private JPanel login;
    private JLabel username;
    private JPanel usernameJP;
    private JButton loginButton;
    private JPasswordField passwordField1;
    private JTextField textField1;
    private static final JFrame frame = new JFrame("login");

    public JFrame getFrame() {
        return frame;
    }


    public login(YlAdminService ylAdminService, YlUserService ylUserService) {
        this.ylAdminService = ylAdminService;
        this.ylUserService = ylUserService;
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                // 设置查询条件
                YlAdminEntity ylAdminEntity = new YlAdminEntity();
                ylAdminEntity.setName(textField1.getText());
                ylAdminEntity.setPassword(String.valueOf(passwordField1.getPassword()));
                QueryWrapper<YlAdminEntity> queryWrapper = new QueryWrapper<>(ylAdminEntity);

                // 查询是否存在用户
                List<YlAdminEntity> adminEntities = ylAdminService.list(queryWrapper);
                if (adminEntities.size()==0){
                    JOptionPane.showMessageDialog(null, "用户名或密码错误", "", JOptionPane.ERROR_MESSAGE);
                }
                else {
                    frame.dispose();
                    index index = new index(ylUserService);
                    index.entry();
                }
            }
        });
    }

    public void entry() {
        JFrame frame = getFrame();
        frame.setContentPane(login);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

}
